package ph.com.metrobank.fdms.consumer.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(properties = {"spring.main.banner-mode=off"})
public class ConsumerRequestModelTest {
	
	@Test
	@DisplayName("Test ConsumerRequest model")
	void testA() 
	{
		ConsumerRequestModel consumerRequestModel = new ConsumerRequestModel();
		
		consumerRequestModel.setTopic("topicSample");
		consumerRequestModel.setUuid("uuidSample");
		
		assertEquals("topicSample", consumerRequestModel.getTopic());
		assertEquals("uuidSample", consumerRequestModel.getUuid());
		
	}

}
