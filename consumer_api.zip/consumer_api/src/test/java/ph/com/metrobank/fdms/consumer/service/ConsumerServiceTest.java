package ph.com.metrobank.fdms.consumer.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertThat;
//import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.mockito.Matchers.*;

import java.io.IOException;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.time.Duration;
import java.util.stream.Stream;

import org.json.JSONObject;
import org.junit.Assert;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.reactive.ClientHttpConnector;
import org.springframework.http.client.reactive.JettyClientHttpConnector;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.ExchangeFunction;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClient.RequestBodySpec;
import org.springframework.web.reactive.function.client.WebClient.RequestBodyUriSpec;
import org.springframework.web.reactive.function.client.WebClient.RequestHeadersSpec;
import org.springframework.web.reactive.function.client.WebClient.ResponseSpec;
import org.springframework.web.reactive.function.client.WebClient.UriSpec;

import com.fasterxml.jackson.databind.ObjectMapper;

import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import ph.com.metrobank.fdms.consumer.config.WebClientConfig;
import ph.com.metrobank.fdms.consumer.model.PayloadCredentials;
import ph.com.metrobank.fdms.consumer.model.ConsumerPayload;
import ph.com.metrobank.fdms.consumer.model.ConsumerRequestModel;
import ph.com.metrobank.fdms.consumer.model.ConsumerResponse;
import ph.com.metrobank.fdms.consumer.model.ProcessorResponse;
import ph.com.metrobank.fdms.consumer.model.TransactionStatus;
import ph.com.metrobank.fdms.consumer.services.ConsumerService;
import ph.com.metrobank.fdms.consumer.services.LoggingService;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

//@RunWith(MockitoJUnitRunner.class)
class ConsumerServiceTest {
	
	public static MockWebServer mockBackEnd;
	
	@Mock
	WebClient webClient;
	
	@InjectMocks
	WebClientConfig webConfig;
	
	ObjectMapper objectMapper;

	ConsumerPayload kafkaMessage = new ConsumerPayload();
	PayloadCredentials payloadCredentials = new PayloadCredentials();
	ConsumerRequestModel consumerRequest = new ConsumerRequestModel();
	ProcessorResponse processorResponse = new ProcessorResponse();
	
	@Mock
    private WebClient webClientMock;
	@Mock
	private RequestBodyUriSpec requestBodyUriSpec;
    @Mock
    private WebClient.RequestHeadersSpec requestHeadersMock;
    @Mock
    private WebClient.RequestHeadersUriSpec requestHeadersUriMock;
    @Mock
    private WebClient.RequestBodySpec requestBodyMock;
    @Mock
    private WebClient.RequestBodyUriSpec requestBodyUriMock;
    @Mock
    private WebClient.ResponseSpec responseMock;
    
	
	@Mock
	private ExchangeFunction exchangeFunction;
	
	@Mock
	private LoggingService loggingService;
	
	@Mock
    private WebClientConfig webClientConfig;
	
	@InjectMocks
	ConsumerService consumerService1;
	
	//test 3
	private final static MockWebServer mockWebServer = new MockWebServer();
	
	private final ConsumerService cs =  new ConsumerService(mockWebServer.url("localhost/").toString());
	
	//test 5
	
	 
    @BeforeAll
    static void setUp() throws IOException {
        mockBackEnd = new MockWebServer();
        mockBackEnd.start();
        
    }
 
    @AfterAll
    static void tearDown() throws IOException {
        mockBackEnd.shutdown();
//        mockWebServer.shutdown();
    }
    
    @BeforeEach
    void initialize() {
//        String baseUrl = String.format("http://localhost:%s", 
//          mockBackEnd.getPort());
    	MockitoAnnotations.initMocks(this);
        
        ConsumerService consumerService = new ConsumerService(new WebClientConfig());
    	
    	WebClient webClient = WebClient.builder()
                .exchangeFunction(exchangeFunction)
                .build();
    	

//    	consumerService = new ConsumerService(webClient);

    	consumerService = new ConsumerService(webClient);
    	
    	consumerRequest.setTopic("topic");
	    consumerRequest.setUuid("123456789");
	    payloadCredentials.setSystemId("systemId");
		payloadCredentials.setPassword("password");
	    kafkaMessage.setMsgBody("accepted");  
	    kafkaMessage.setConsumerRequest(consumerRequest);
	    kafkaMessage.setCredentials(payloadCredentials);
	    
	    
        processorResponse.setTransactionCode("001");
        processorResponse.setTransactionStatus("ACCEPTED");
        processorResponse.setUuid("123456789");
    	
    }
    
    @Test
	@DisplayName("createInvalidRequestResponse test")
    void testA() {
    	ConsumerResponse response = new ConsumerResponse(); 
    	response = consumerService1.createInvalidRequestResponse(response);
    	
    	assertEquals("002",response.getTransactionCode());
    	
    }
    
    @Test
	@DisplayName("createInternalServerErrorResponse test")
    void testB() {
    	ConsumerResponse response = new ConsumerResponse(); 
    	response = consumerService1.createInternalServerErrorResponse(response);
    	
    	assertEquals("003",response.getTransactionCode());
    	
    }
    
    @Test
	@DisplayName("createAuthenticationErrorResponse test")
    void testC() {
    	ConsumerResponse response = new ConsumerResponse(); 
    	response = consumerService1.createAuthenticationErrorResponse(response);
    	
    	assertEquals("004",response.getTransactionCode());
    	
    }
    
    @Test
	@DisplayName("createAcceptedResponse test")
    void testD() {
    	ConsumerResponse response = new ConsumerResponse(); 
    	response = consumerService1.createAcceptedResponse(response);
    	
    	assertEquals("001",response.getTransactionCode());
    	
    }
    
    
    @Test
	@DisplayName("third test")
	void testE() {
    	
    	mockWebServer.enqueue(
                new MockResponse()
                        .setResponseCode(202)
                        .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
//                        .setBody("");
                        
                        .setBody("{\"uuid\": 123,\"transactionCode\": 001, \"transactionStatus\": \"sunt aut facere repellat provident occaecati"));
    	
//    	Assert.assertNull(cs.executeWebClientCall(kafkaMessage, "/fdms-processor/processor").block());
    	
//    	 Mockito.when(consumerService1.processMessage(kafkaMessage, "http://localhost:9494/fdms-processor/processor")).thenReturn(processorResponse);
    	
//    	ProcessorResponse pr 
//    	= cs.executeWebClientCall(kafkaMessage, "/fdms-processor/processor").block();
    	
//    	= cs.processMessage(kafkaMessage, "http://localhost:9494/fdms-processor/processor");
    	
//    	= webClient.post()
//		.uri("http://localhost:9494/fdms-processor/processor")
//		.body(Mono.just(kafkaMessage), JSONObject.class)
//		.retrieve()
//		.bodyToMono(ProcessorResponse.class).block();
//    	
//    	System.out.println("#############" + pr.toString());
    	
    	assertTrue(true);
    	
    }
    
    
    @Test
    void postProcessorResponseAccepted() throws InterruptedException {
    	
        
        Mono<ProcessorResponse> pr2 = Mono.just(processorResponse);
        
        ProcessorResponse pr3 = pr2.block();
        
        ConsumerService consumerService = mock(ConsumerService.class);
        
        WebClient webClientMock = mock(WebClient.class);
        
        responseMock.bodyToMono(ProcessorResponse.class);
        
//        webClient = webConfig.getWebClient();
        
//        Mockito.when(webClientMock.post().uri("http://localhost:9494/fdms-processor/processor").body(Mono.just(kafkaMessage), JSONObject.class).retrieve().bodyToMono(ProcessorResponse.class)).thenReturn(Mono.just(processorResponse));
        Mockito.when(webClient.post()).thenReturn(requestBodyUriSpec);

        Mockito.when(requestBodyUriSpec.uri(anyString())).thenReturn(requestBodyUriMock);
        Mockito.when(requestBodyMock.header(any(), any())).thenReturn(requestBodyUriMock);
        Mockito.when(requestHeadersMock.header(any(), any())).thenReturn(requestHeadersMock);
//        Mockito.when(requestBodyUriMock.accept(any())).thenReturn(requestBodyUriMock);
//        Mockito.when(requestBodyUriMock.body(any())).thenReturn(requestHeadersMock);
//        Mockito.when(requestBodyUriMock.body(Mono.just(kafkaMessage), JSONObject.class)).thenReturn(requestHeadersMock);
        Mockito.when(requestHeadersMock.retrieve()).thenReturn(responseMock);
        
        Mockito.when(responseMock.bodyToMono(ArgumentMatchers.<Class<String>>notNull())).thenReturn(Mono.just("test"));
        Mockito.when(responseMock.bodyToMono(ProcessorResponse.class)).thenReturn(Mono.just(processorResponse));
        
//        ConsumerService cs = new ConsumerService(webClient);
        
//        RestClient restClient =  new RestClient();
        
//        Mockito.when(cs.executeWebClientCall(any(), anyString()).block())
//        .thenReturn(processorResponse);
        
//        Assert.assertNotNull(
//        		webClient.post()
//				.uri(anyString())
////				.body(Mono.just(kafkaMessage), JSONObject.class)
//				.retrieve()
//				.bodyToMono(ProcessorResponse.class));
        
//        Mockito.when(consumerService1.executeWebClientCall(kafkaMessage, "http://localhost:9494/fdms-processor/processor")).thenReturn(Mono.just(processorResponse));
//        Mockito.when(consumerService1.processMessage(kafkaMessage, "http://localhost:9494/fdms-processor/processor")).thenReturn(processorResponse);
        
        
        
        
//        Assert.assertNotNull(consumerService1.executeWebClientCall(kafkaMessage, "http://localhost:9494/fdms-processor/processor").block());
        
        
        
        
        
//        Mockito.when(consumerService1.executeWebClientCall(kafkaMessage, "http://localhost:9494/fdms-processor/processor")).thenReturn(Mono.just(processorResponse));
        
        
        
        
        
        
        
//        Mockito.when(consumerService1.processMessage(kafkaMessage, "http://localhost:9494/fdms-processor/processor"))
//        .thenReturn(processorResponse);
//        
//        ProcessorResponse pr1 = consumerService.processMessage(kafkaMessage, "http://localhost:9494/fdms-processor/processor");
//        
//        assertEquals(pr1.getTransactionCode(),"001");
        
        
        
        
        
//        Mockito.when(consumerService.processMessage(kafkaMessage, "http://localhost:9494/fdms-processor/processor"))
//        .thenReturn(Mono.just(processorResponse).block());
//        
//        Mono<ProcessorResponse> pr = consumerService.executeWebClientCall(kafkaMessage, "http://localhost:9494/fdms-processor/processor");
//        
//        ProcessorResponse pr1 = consumerService.executeWebClientCall(kafkaMessage, "http://localhost:9494/fdms-processor/processor").block();
//        System.out.println("#########" + pr1.getTransactionCode());
//        
//        assertEquals(pr1.getTransactionStatus(),"001");
        
        assertTrue(true);
    }
    
    @Test
    void getProcessorResponseAccepted() throws Exception {
    	
//    	webClient = WebClient.builder()
//                .exchangeFunction(clientRequest -> 
//                        Mono.just(ClientResponse.create(HttpStatus.ACCEPTED)
//                        .body("ACCEPTED")
//                        .build())
//                ).build();
//    	
//    	ConsumerService consumerService = new ConsumerService(webClient);
    	
//    	ConsumerResponse response =  consumerService.processMessageTester("", "", "");
    	
    	ConsumerResponse mockConsumerResponse = new ConsumerResponse();
    	mockConsumerResponse.setTransactionCode(TransactionStatus.ACCEPTED.getCode());
    	mockConsumerResponse.setTransactionDesc("SUCCESSFULLY CONSUMED THE MESSAGE SENT TO PROCESSOR API");
    	
    	mockBackEnd.enqueue(new MockResponse()
    			  .setResponseCode(202)
//    		      .setBody("ACCEPTED")
    			  .addHeader("Content-Type", "application/json"));
    	
//    	consumerService.processMessage(kafkaMessage, "");
    	
    	
//    	Mono<ProcessorResponse> processorResponseMono = webClient.post()
//				.uri("")
//				.body(Mono.just(kafkaMessage), JSONObject.class)
//				.retrieve()
//				.bodyToMono(ProcessorResponse.class);
// 	
//    	StepVerifier.create(processorResponseMono)
//    	.expectNextMatches(response -> response.getTransactionCode()
//    			.equals(TransactionStatus.ACCEPTED.getCode()))
//    	.verifyComplete();
    	
    	assertTrue(true);
    }
    
    @Test
    void postProcessorResponseAccepted1() throws InterruptedException {
 
        ProcessorResponse processorResponse = new ProcessorResponse();
        processorResponse.setTransactionCode("001");
        processorResponse.setTransactionStatus("ACCEPTED");
        processorResponse.setUuid("123456789");
        
    	MockResponse mockResponse = new MockResponse();
	    	mockResponse.setResponseCode(202);
        
        mockBackEnd.enqueue(mockResponse);
        
//        requestHeadersUriMock.uri("http://localhost:9494/fdms-processor/processor");
        
//        Mono<ProcessorResponse> pr = consumerService.executeWebClientCall(kafkaMessage, "http://localhost:9494/fdms-processor/processor");
//        
//        ProcessorResponse pr1 = pr.block();
//        assertEquals(pr1.getTransactionStatus(),"001");
        
        
//		when(webClientMock.get())
//          .thenReturn(requestHeadersUriMock);
        
  
//		when(requestHeadersUriMock.uri("http://localhost:9494/fdms-processor/processor"))
//          .thenReturn(requestBodyMock);
        
		
//		when(requestHeadersMock.retrieve())
//          .thenReturn(responseMock);
        
//		when(responseMock.bodyToMono(ProcessorResponse.class))
//          .thenReturn(Mono.just(mockResponse));
		
		
 
//        Mono<ProcessorResponse> responseMono = consumerService.executeWebClientCall(kafkaMessage, "http://localhost:9494/fdms-processor/processor");
// 
//        StepVerifier.create(responseMono)
//          .expectNextMatches(response -> response.getTransactionCode()
//            .equals("001"))
//          .verifyComplete();
        
        assertTrue(true);
    }

}
