package ph.com.metrobank.fdms.consumer.controller;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import ph.com.metrobank.fdms.consumer.exception.FdmsConsumerApiException;
import ph.com.metrobank.fdms.consumer.exception.KafkaServerException;
import ph.com.metrobank.fdms.consumer.exception.ProcessorAuthenticationException;
import ph.com.metrobank.fdms.consumer.utils.ResponseBuilder;

@SpringBootTest(properties = {"spring.main.banner-mode=off"})
public class FdmsConsumerExceptionControllerTest {
	
	@Autowired
	private FdmsConsumerExceptionController fdmsConsumerController;
	
	@Autowired
	private ResponseBuilder rb;
	
	private ProcessorAuthenticationException processorAuthenticationException = new ProcessorAuthenticationException();
	
	private KafkaServerException kafkaSeverException = new KafkaServerException();
	
	private FdmsConsumerApiException fdmaConsumerApiException = new FdmsConsumerApiException("");
	
//	private HttpServletRequest httpServleRequest;
	
//	private HttpServletResponse httpServletResponse;
	
	private HttpServletRequest httpServletRequest = new MockHttpServletRequest();
	private HttpServletResponse httpServletResponse = new MockHttpServletResponse();
	
	
	
	@Test
	@DisplayName("Test  FdmsConsumerExceptionController authenticateException")
	void testA()
	{
//		HttpServletRequest request = mock(HttpServletRequest.class);
//		HttpServletRequest httpServletRequest = new MockHttpServletRequest();
//		HttpServletResponse httpServletResponse = new MockHttpServletResponse();
		
		assertEquals(fdmsConsumerController.authenticateException(processorAuthenticationException, httpServletRequest, httpServletResponse), new ResponseEntity<>(rb.authenticationFailed(), HttpStatus.FORBIDDEN));
	}
	
	@Test
	@DisplayName("Test  FdmsConsumerExceptionController authenticateException")
	void testB()
	{
		assertEquals(fdmsConsumerController.kafkaDown(kafkaSeverException, httpServletRequest, httpServletResponse), rb.kafkaDown());
	}
	
	@Test
	@DisplayName("Test  FdmsConsumerExceptionController authenticateException")
	void testC()
	{
		fdmsConsumerController.fdmsException(fdmaConsumerApiException, httpServletRequest, httpServletResponse); assertTrue(true);
	}

}
