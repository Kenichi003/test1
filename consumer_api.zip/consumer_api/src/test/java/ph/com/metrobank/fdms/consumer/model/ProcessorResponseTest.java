package ph.com.metrobank.fdms.consumer.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import ph.com.metrobank.fdms.consumer.services.GenerateUUIDService;

@SpringBootTest(properties = {"spring.main.banner-mode=off"})
public class ProcessorResponseTest {
	
	@Test
	@DisplayName("Test ProcessorResponse model")
	void testA() 
	{
		ProcessorResponse processorResponse = new ProcessorResponse();
		GenerateUUIDService generateUUIDService = new GenerateUUIDService();
		String uuid = generateUUIDService.generateUUID();		
		processorResponse.setTransactionCode("transactionCodeSample");
		processorResponse.setTransactionStatus("transactionStatusSample");
		processorResponse.setUuid(uuid);
		
		assertEquals("transactionCodeSample", processorResponse.getTransactionCode());
		assertEquals("transactionStatusSample", processorResponse.getTransactionStatus());
		assertEquals(uuid, processorResponse.getUuid());
		
	}

}
