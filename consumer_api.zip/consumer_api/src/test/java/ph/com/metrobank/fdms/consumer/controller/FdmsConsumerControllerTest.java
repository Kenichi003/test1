package ph.com.metrobank.fdms.consumer.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import ph.com.metrobank.fdms.consumer.model.FdmsPayload;
import ph.com.metrobank.fdms.consumer.model.PayloadCredentials;
import ph.com.metrobank.fdms.consumer.utils.ResponseBuilder;

@SpringBootTest(properties = {"spring.main.banner-mode=off"})
public class FdmsConsumerControllerTest {
	
	@Autowired
	private FdmsConsumerController fdmsConsumerController;
	
	@Autowired
	private ResponseBuilder rb;

	private FdmsPayload fdmsPayload;

	@Test
	@DisplayName("Test FdmsConsumerController autoKafkaListener")
	void testA()
	{
		fdmsPayload = getValidPayload();
		
		assertEquals(rb.responseAccepted(),fdmsConsumerController.autoKafkaListener("true", fdmsPayload));
		
	}
	
	@Test
	@DisplayName("Test FdmsConsumerController autoKafkaATMListener")
	void testB()
	{
		fdmsPayload = getValidPayload();
		
		assertEquals(rb.responseAccepted(),fdmsConsumerController.autoKafkaATMListener("true", fdmsPayload));
		
	}
	
	
	private FdmsPayload getValidPayload() {
		
		FdmsPayload fdmsPayload = new FdmsPayload();
		
		PayloadCredentials payloadCredentials = new PayloadCredentials();
		payloadCredentials.setPassword("5D5143674779916A702B7FF8E34CB22A3D1ADD2AC77F714E9D2FBDC9FCC0A59C");
		payloadCredentials.setSystemId("FDMS_PROCESSOR");
		
		fdmsPayload.setEventType("eventTypeSample");
		fdmsPayload.setEventSubType("eventSubTypeSample");
		fdmsPayload.setEventName("eventNameSample");
		fdmsPayload.setSystemTraceAuditNo("systemTraceAuditNo");
		fdmsPayload.setTranReferenceNo("tranReferenceNoSample");
		fdmsPayload.setMsgBody("msgBodySample");
		fdmsPayload.setCredentials(payloadCredentials);
		
		
		return fdmsPayload;
		
	}
	
	
	
	

}
