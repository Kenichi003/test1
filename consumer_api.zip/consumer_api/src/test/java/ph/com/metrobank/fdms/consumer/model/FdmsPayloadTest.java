package ph.com.metrobank.fdms.consumer.model;

import static org.junit.Assert.assertThrows;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import com.fasterxml.jackson.core.JsonProcessingException;

@SpringBootTest(properties = {"spring.main.banner-mode=off"})
public class FdmsPayloadTest {
	
	
	
	@Test
	@DisplayName("Test FdmsPayload model")
	void testA() 
	{
		FdmsPayload fdmsPayload = new FdmsPayload();
		PayloadCredentials payloadCredentials = new PayloadCredentials();
		payloadCredentials.setPassword("passwordSample");
		payloadCredentials.setSystemId("systemIdSample");
		
		fdmsPayload.setEventType("eventTypeSample");
		fdmsPayload.setEventSubType("eventSubTypeSample");
		fdmsPayload.setEventName("eventNameSample");
		fdmsPayload.setSystemTraceAuditNo("systemTraceAuditNo");
		fdmsPayload.setTranReferenceNo("tranReferenceNoSample");
		fdmsPayload.setMsgBody("msgBodySample");
		fdmsPayload.setCredentials(payloadCredentials);
		
		assertEquals("eventTypeSample",fdmsPayload.getEventType());
		assertEquals("eventSubTypeSample",fdmsPayload.getEventSubType());
		assertEquals("eventNameSample",fdmsPayload.getEventName());
		assertEquals("systemTraceAuditNo",fdmsPayload.getSystemTraceAuditNo());
		assertEquals("tranReferenceNoSample",fdmsPayload.getTranReferenceNo());
		assertEquals("msgBodySample",fdmsPayload.getMsgBody());
		
		assertEquals("{\"eventType\":\"eventTypeSample\",\"eventSubType\":\"eventSubTypeSample\",\"eventName\":\"eventNameSample\",\"systemTraceAuditNo\":\"systemTraceAuditNo\",\"tranReferenceNo\":\"tranReferenceNoSample\",\"msgBody\":\"msgBodySample\",\"credentials\":{\"systemId\":\"systemIdSample\",\"password\":\"passwordSample\"}}",fdmsPayload.toString());
		
	}
	

}
