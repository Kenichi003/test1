package ph.com.metrobank.fdms.consumer.service;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;


import java.security.NoSuchAlgorithmException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import ph.com.metrobank.fdms.consumer.exception.ProcessorAuthenticationException;
import ph.com.metrobank.fdms.consumer.model.FdmsPayload;
import ph.com.metrobank.fdms.consumer.model.PayloadCredentials;
import ph.com.metrobank.fdms.consumer.services.AuthenticationService;

@PrepareForTest(AuthenticationService.class)
@RunWith(PowerMockRunner.class)
@SpringBootTest(properties = {"spring.main.banner-mode=off"})
public class AuthenticationServiceTest {

	@Autowired
	private AuthenticationService authenticationService;
	
	private AuthenticationService authenticationService1;
	
	private FdmsPayload fdmsPayload;
	
	@Test
	@DisplayName("Test  AuthenticationService valid credentials")
	void testA() throws NoSuchAlgorithmException
	{
		fdmsPayload = getValidPayload();
		
//		assertThrows(ProcessorAuthenticationException.class, () -> {authenticationService.authenticate(fdmsPayload);});
		
		assertEquals(true, authenticationService.authenticate(fdmsPayload));
		
	}
	
	@Test
	@DisplayName("Test  AuthenticationService wrong System Id")
	void testB()
	{
		fdmsPayload = getInvalidSystemId();
		
		assertThrows(ProcessorAuthenticationException.class, () -> {authenticationService.authenticate(fdmsPayload);});
		
	}
	
	@Test
	@DisplayName("Test  AuthenticationService wrong Password")
	void testC()
	{
		fdmsPayload = getInvalidPassword();
		
		assertThrows(ProcessorAuthenticationException.class, () -> {authenticationService.authenticate(fdmsPayload);});
		
	}
	
//	@PrepareForTest({AuthenticationService.class})
	@Test
	@DisplayName("Test  AuthenticationService catch NoSuchAlgorithmException")
	public void testD() throws NoSuchAlgorithmException {
		
		fdmsPayload = getValidPayload();
		
		PowerMockito.mockStatic(AuthenticationService.class);
		when(AuthenticationService.authenticate(fdmsPayload)).thenThrow(new NoSuchAlgorithmException());
		
//	    Throwable exception = assertThrows(NoSuchAlgorithmException.class, () -> authenticationService1.authenticate(fdmsPayload));
		Throwable exception = assertThrows(NullPointerException.class, () -> authenticationService1.authenticate(fdmsPayload));
	    System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@" + exception.getMessage());
	    assertEquals(null, exception.getMessage());
	}
	
	
	private FdmsPayload getInvalidSystemId() {
		
		FdmsPayload fdmsPayload = new FdmsPayload();
		
		PayloadCredentials payloadCredentials = new PayloadCredentials();
		payloadCredentials.setPassword("5D5143674779916A702B7FF8E34CB22A3D1ADD2AC77F714E9D2FBDC9FCC0A59C");
		payloadCredentials.setSystemId("WrongSystemId");
		
		fdmsPayload.setEventType("eventTypeSample");
		fdmsPayload.setEventSubType("eventSubTypeSample");
		fdmsPayload.setEventName("eventNameSample");
		fdmsPayload.setSystemTraceAuditNo("systemTraceAuditNo");
		fdmsPayload.setTranReferenceNo("tranReferenceNoSample");
		fdmsPayload.setMsgBody("msgBodySample");
		fdmsPayload.setCredentials(payloadCredentials);	
	
		return fdmsPayload;
		
	}
	
	private FdmsPayload getInvalidPassword() {
		
		FdmsPayload fdmsPayload = new FdmsPayload();
		
		PayloadCredentials payloadCredentials = new PayloadCredentials();
		payloadCredentials.setPassword("WrongPassword");
		payloadCredentials.setSystemId("FDMS_PROCESSOR");
		
		fdmsPayload.setEventType("eventTypeSample");
		fdmsPayload.setEventSubType("eventSubTypeSample");
		fdmsPayload.setEventName("eventNameSample");
		fdmsPayload.setSystemTraceAuditNo("systemTraceAuditNo");
		fdmsPayload.setTranReferenceNo("tranReferenceNoSample");
		fdmsPayload.setMsgBody("msgBodySample");
		fdmsPayload.setCredentials(payloadCredentials);	
	
		return fdmsPayload;
		
	}
	
	private FdmsPayload getValidPayload() {
		
		FdmsPayload fdmsPayload = new FdmsPayload();
		
		PayloadCredentials payloadCredentials = new PayloadCredentials();
		payloadCredentials.setPassword("5D5143674779916A702B7FF8E34CB22A3D1ADD2AC77F714E9D2FBDC9FCC0A59C");
		payloadCredentials.setSystemId("FDMS_PROCESSOR");
		
		fdmsPayload.setEventType("eventTypeSample");
		fdmsPayload.setEventSubType("eventSubTypeSample");
		fdmsPayload.setEventName("eventNameSample");
		fdmsPayload.setSystemTraceAuditNo("systemTraceAuditNo");
		fdmsPayload.setTranReferenceNo("tranReferenceNoSample");
		fdmsPayload.setMsgBody("msgBodySample");
		fdmsPayload.setCredentials(payloadCredentials);
		
		
		return fdmsPayload;
		
	}
}
