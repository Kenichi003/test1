package ph.com.metrobank.fdms.consumer;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FdmsConsumerApplicationTests {

	@Test
	void contextLoads() {
		FdmsConsumerApplication.main(new String[] {});
	}

}
