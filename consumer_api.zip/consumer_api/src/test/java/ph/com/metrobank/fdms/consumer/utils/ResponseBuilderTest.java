package ph.com.metrobank.fdms.consumer.utils;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

public class ResponseBuilderTest {
	
	@Autowired
	ResponseBuilder responseBuilder = new ResponseBuilder();
	
	@Test
	@DisplayName("test response builder all status codes")
	void testA() {
		
		assertEquals("001", responseBuilder.responseAccepted().get(FdmsConstants.RESPONSE_TRANSCODE));
		assertEquals(200, responseBuilder.success().get(FdmsConstants.RESPONSE_TRANSCODE));
		assertEquals("005", responseBuilder.validationFailed("12345678").get(FdmsConstants.RESPONSE_TRANSCODE));
		assertEquals(400, responseBuilder.kafkaDown().get(FdmsConstants.RESPONSE_TRANSCODE));
		assertEquals("004", responseBuilder.authenticationFailed().get(FdmsConstants.RESPONSE_TRANSCODE));
		assertEquals("responseMsg", responseBuilder.fdmsErrorResponse("responseCode", "responseMsg").get("responseCode"));
		

		
	}


}
