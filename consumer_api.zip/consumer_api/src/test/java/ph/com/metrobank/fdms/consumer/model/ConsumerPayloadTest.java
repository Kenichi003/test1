package ph.com.metrobank.fdms.consumer.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(properties = {"spring.main.banner-mode=off"})
public class ConsumerPayloadTest {
	
	@Test
	@DisplayName("Test ConsumerPayload model")
	void testA() 
	{
		ConsumerPayload consumerPayload = new ConsumerPayload();
		ConsumerRequestModel consumerRequestModel = new ConsumerRequestModel();
		PayloadCredentials payloadCredentials = new PayloadCredentials();
		
		consumerPayload.setConsumerRequest(consumerRequestModel);
		consumerPayload.setCredentials(payloadCredentials);
		consumerPayload.setMsgBody("msgBodySample");
		consumerPayload.setTransDateTimestamp("transDateTimeStampSample");
		
		assertEquals(consumerRequestModel, consumerPayload.getConsumerRequest());
		assertEquals(payloadCredentials, consumerPayload.getCredentials());
		assertEquals("msgBodySample", consumerPayload.getMsgBody());
		assertEquals("transDateTimeStampSample", consumerPayload.getTransDateTimestamp());
		
		
	}

}
