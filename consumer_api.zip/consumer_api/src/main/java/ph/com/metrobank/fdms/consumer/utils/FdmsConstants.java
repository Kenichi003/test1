package ph.com.metrobank.fdms.consumer.utils;

public class FdmsConstants {
	
	private FdmsConstants()
	{

	}

	public static final String FDMS_DATEFORMAT = "yyyy-MM-dd HH:mm:ss.SSS";
	
	public static final int REQUEST_VALIDATION_ERROR_CODE = 100;
	public static final String REQUEST_VALIDATION_ERROR_MSG = "Request Validation error (i.e. JSON format, missing required field/s on Payload.";

	public static final int PRODUCER_API_EXCEPTION_CODE = 300;
	public static final String PRODUCER_API_EXCEPTION_MSG = "Internal server error / API server is down.";

	public static final int KAFKA_SERVER_DOWN_CODE = 400;
	public static final String KAFKA_SERVER_DOWN_MSG = "Internal server error – i.e. KAFKA server is down";

	public static final int AUTHENTICATION_ERROR_CODE = 500;
	public static final String AUTHENTICATION_ERROR_MSG = "Authentication failed";

	public static final int SUCCESS_CODE = 200;
	public static final String SUCCESS_MSG = "Success – message has been published to Kafka topic";
	
	public static final String PROCESSOR_ACCEPTED_CODE = "001";//Response Code for Accepted(Consumer API)
	public static final String PROCESSOR_ACCEPTED_MSG = "ACCEPTED";
	
	public static final String PROCESSOR_AUTH_ERR_CODE = "004";//Response Code for API Error
	public static final String PROCESSOR_AUTH_ERR_MSG = "Authentication error";

	public static final String CONSUMER_API_ERROR = "Internal Server Error";
	public static final String CONSUMER_API_ERROR_CODE = "005";


	public static final String RESPONSE_UIID = "uuid";
	public static final String RESPONSE_STATUS_DESC = "transactionStatus";
	
	public static final String RESPONSE_TRANSCODE = "transactionCode";
	public static final String RESPONSE_TRANSDESC = "transactionDesc";
	public static final String RESPONSE_TRANSDATE = "transactionDate";


}
