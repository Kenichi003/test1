/*
 *  Copyright (c) 2019 Metropolitan Bank & Trust Company
 *
 *  @author 33460
 *  @date 2019-08-16
 *  @email mark.to@metrobank.com.ph
 */
package ph.com.metrobank.fdms.consumer.model;

public class TransactionDesc {

	public static final String ACCEPTED = "SUCCESSFULLY CONSUMED THE MESSAGE SENT TO PROCESSOR API";
	public static final String INVALID_REQUEST = "INVALID REQUEST";
	public static final String INTERNAL_SERVER_ERROR_ON_KAFKA = "ERROR CONSUMING MESSAGE ON TOPIC";
	public static final String AUTHENTICATION_ERROR = "INVALID API CREDETIALS";
	
	
}
