package ph.com.metrobank.fdms.consumer.utils;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtils {
	
	private DateUtils()
	{

	}

	public static String transactionDate(String dateFormat)
	{
		SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);
		Date date = new Date(System.currentTimeMillis());
		return formatter.format(date);
	}


}
