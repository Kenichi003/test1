package ph.com.metrobank.fdms.consumer.model;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModelProperty;

public class PayloadCredentials implements Model {

	@ApiModelProperty(value = "system ID", name = "systemId", dataType = "String", example = "")
	@NotNull
	@Size(min = 1, max = 100)
	private String systemId;
	
	@ApiModelProperty(value = "password", name = "password", dataType = "String", example = "")
	@NotNull
	@Size(min = 1, max = 100)
	private String password;

	public String getSystemId() {
		return systemId;
	}

	public void setSystemId(String systemId) {
		this.systemId = systemId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
}
