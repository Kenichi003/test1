package ph.com.metrobank.fdms.consumer.model;

import io.swagger.annotations.ApiModelProperty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;


public class ConsumerRequestModel implements Model{

	@ApiModelProperty(value = "uuid", name = "uuid", dataType = "String", example = "")
	@NotNull
	@Size(min = 1, max = 100)
	private String uuid;
	
	@ApiModelProperty(value = "topic", name = "topic", dataType = "String", example = "")
	@NotNull
	@Size(min = 1, max = 100)
	private String topic;
	
	public String getUuid()
	{
		return uuid;
	}

	public void setUuid(String uuid)
	{
		this.uuid = uuid;
	}
	
	public String getTopic()
	{
		return topic;
	}

	public void setTopic(String topic)
	{
		this.topic = topic;
	}

}
