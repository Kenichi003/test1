/*
 *  Copyright (c) 2019 Metropolitan Bank & Trust Company
 *
 *  @author 33460
 *  @date 2019-08-16
 *  @email mark.to@metrobank.com.ph
 */
package ph.com.metrobank.fdms.consumer.model;

public class TraceLog {
	
	public static final String FDMS_KAFKA_SERVICE_LISTENER = "|FDMS_KAFKA_SERVICE_LISTENER: ";
	public static final String FDMS_KAFKA_SERVICE_LISTENER_JSON_VALIDATOR = "|FDMS_KAFKA_SERVICE_LISTENER_JSON_VALIDATOR: ";
	public static final String FDMS_KAFKA_SERVICE_PROCESSOR_RESPONSE = "|FDMS_KAFKA_SERVICE_PROCESSOR_RESPONSE: ";
	public static final String FDMS_KAFKA_SERVICE_POST_TO_PROCESSOR = "|FDMA_KAFKA_SERVICE_POST_TO_PROCESSOR: ";
	
	public static final String FDMS_CONSUMER_SERVICE = "|FDMS_CONSUMER_SERVICE: ";
	public static final String FDMS_CONSUMER_SERVICE_INVALID_REQUEST = "|FDMS_CONSUMER_SERVICE_INVALID_REQUEST: ";
	public static final String FDMS_CONSUMER_SERVICE_KAFKA_JSON_DESERIALIZER = "|FDMS_CONSUMER_SERVICE_KAFKA_JSON_DESERIALIZER: ";
	public static final String FDMS_CONSUMER_SERVICE_AUTHENTICATOR = "|FDMS_CONSUMER_SERVICE_AUTHENTICATOR: ";
	
	public static final String FDMS_KAFKA_CONTROLLER = "|FDMS_KAFKA_CONTROLLER: ";
	public static final String FDMS_CONSUMER_EXCEPTION_CONTROLLER = "|FDMS_CONSUMER_EXCEPTION_CONTROLLER: ";


}
