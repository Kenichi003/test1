package ph.com.metrobank.fdms.consumer.model;

public interface Model
{

}
