/*
 *  Copyright (c) 2019 Metropolitan Bank & Trust Company
 *
 *  @author 33460
 *  @date 2019-08-16
 *  @email mark.to@metrobank.com.ph
 */
package ph.com.metrobank.fdms.consumer.services;

import java.util.UUID;
import org.springframework.stereotype.Service;

@Service
public class GenerateUUIDService {

	public String generateUUID() {
		UUID uuid = UUID.randomUUID();
		return uuid.toString();
	}

}
