package ph.com.metrobank.fdms.consumer.model;

import io.swagger.annotations.ApiModelProperty;
import ph.com.metrobank.fdms.consumer.services.LoggingService;
import ph.com.metrobank.fdms.consumer.utils.FdmsConstants;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.beans.factory.annotation.Autowired;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.google.gson.annotations.Expose;

public class FdmsPayload implements Model {
	
	@Autowired
	private LoggingService loggingService;
	
	@Expose
	@ApiModelProperty(value = "event type", name = "eventType", dataType = "String", example = "ft")
	@NotNull
	@Size(min = 1, max = 100)
	private String eventType;

	@Expose
	@ApiModelProperty(value = "event sub type", name = "eventSubType", dataType = "String", example = "cardtxn")
	@NotNull
	@Size(min = 1, max = 100)
	private String eventSubType;

	@Expose
	@ApiModelProperty(value = "event name", name = "eventName", dataType = "String", example = "ft_cardtxn")
	@NotNull
	@Size(min = 1, max = 100)
	private String eventName;

	@Expose
	@ApiModelProperty(value = "system trace audito number", name = "systemTraceAuditNo", dataType = "String", example = "1234456")
	@NotNull
	@Size(min = 1, max = 100)
	private String systemTraceAuditNo;

	@Expose
	@ApiModelProperty(value = "transaction ref num", name = "tranReferenceNo", dataType = "String", example = "1234456")
	@NotNull
	@Size(min = 1, max = 100)
	private String tranReferenceNo;

	@Expose
	@ApiModelProperty(value = "request body", name = "msgBody", dataType = "String", example = "0210FA3E47910EB0C608000010000400")
	@NotNull
	@Size(min = 1, max = 5000)
	private String msgBody;

	private PayloadCredentials credentials;
	
	public String getEventType() {
		return eventType;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

	public String getEventSubType() {
		return eventSubType;
	}

	public void setEventSubType(String eventSubType) {
		this.eventSubType = eventSubType;
	}

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public String getSystemTraceAuditNo() {
		return systemTraceAuditNo;
	}

	public void setSystemTraceAuditNo(String systemTraceAuditNo) {
		this.systemTraceAuditNo = systemTraceAuditNo;
	}

	public String getTranReferenceNo() {
		return tranReferenceNo;
	}

	public void setTranReferenceNo(String tranReferenceNo) {
		this.tranReferenceNo = tranReferenceNo;
	}

	public String getMsgBody() {
		return msgBody;
	}

	public void setMsgBody(String msgBody) {
		this.msgBody = msgBody;
	}

	public PayloadCredentials getCredentials() {
		return credentials;
	}

	public void setCredentials(PayloadCredentials credentials) {
		this.credentials = credentials;
	}
	
	@Override
	public String toString() {
		try {
			return new ObjectMapper().enable(SerializationFeature.ORDER_MAP_ENTRIES_BY_KEYS).writeValueAsString(this);
		} catch (JsonProcessingException e) {
			loggingService.error(this.getClass().toString(), FdmsConstants.CONSUMER_API_ERROR_CODE, e.getMessage(), e);
			return "";
		}
	}


}
