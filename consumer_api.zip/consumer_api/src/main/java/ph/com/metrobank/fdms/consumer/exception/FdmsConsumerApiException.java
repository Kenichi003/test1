package ph.com.metrobank.fdms.consumer.exception;

public class FdmsConsumerApiException extends RuntimeException {
	
	private static final long serialVersionUID = 1L;

	public FdmsConsumerApiException(String message) {
		super(message);
	}
}
