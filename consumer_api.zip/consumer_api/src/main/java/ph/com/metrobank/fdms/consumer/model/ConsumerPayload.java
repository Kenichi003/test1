package ph.com.metrobank.fdms.consumer.model;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.google.gson.annotations.Expose;

import io.swagger.annotations.ApiModelProperty;

public class ConsumerPayload implements Model {
	
	@Expose
	@ApiModelProperty(value = "request body", name = "msgBody", dataType = "String", example = "0210FA3E47910EB0C608000010000400")
	@NotNull
	@Size(min = 1, max = 5000)
	private String msgBody;
	
	private PayloadCredentials credentials;
	
	private ConsumerRequestModel consumerRequest;
	
	private String transDateTimestamp;

	public String getMsgBody() {
		return msgBody;
	}

	public void setMsgBody(String msgBody) {
		this.msgBody = msgBody;
	}

	public PayloadCredentials getCredentials() {
		return credentials;
	}

	public void setCredentials(PayloadCredentials credentials) {
		this.credentials = credentials;
	}

	public ConsumerRequestModel getConsumerRequest() {
		return consumerRequest;
	}

	public void setConsumerRequest(ConsumerRequestModel consumerRequest) {
		this.consumerRequest = consumerRequest;
	}

	public String getTransDateTimestamp() {
		return transDateTimestamp;
	}

	public void setTransDateTimestamp(String transDateTimestamp) {
		this.transDateTimestamp = transDateTimestamp;
	}
	
	
	

}
