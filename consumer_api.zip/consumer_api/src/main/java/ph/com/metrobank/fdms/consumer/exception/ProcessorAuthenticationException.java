package ph.com.metrobank.fdms.consumer.exception;

public class ProcessorAuthenticationException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public ProcessorAuthenticationException() {
		super();
	}

}
