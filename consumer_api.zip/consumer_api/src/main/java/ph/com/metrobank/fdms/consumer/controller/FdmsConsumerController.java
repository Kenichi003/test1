package ph.com.metrobank.fdms.consumer.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import ph.com.metrobank.fdms.consumer.model.FdmsPayload;
import ph.com.metrobank.fdms.consumer.services.ConsumerService;


@RestController
public class FdmsConsumerController {

	@Autowired
	private ConsumerService consumerService;
	

	@PostMapping(value = "/autoKafka/{auto}")
	public Map<String, Object> autoKafkaListener(@PathVariable("auto") final String figAuto, @RequestBody FdmsPayload payload) {
		
		return consumerService.kafkaToggle(payload, figAuto, "consumer.listen.start");
	}
	
	@PostMapping(value = "/autoKafka/atm/{auto}")
	public Map<String, Object> autoKafkaATMListener(@PathVariable("auto") final String figAuto, @RequestBody FdmsPayload payload) {
		
		return consumerService.kafkaToggle(payload, figAuto, "consumer-atm.listen.start");
	}
	
}
