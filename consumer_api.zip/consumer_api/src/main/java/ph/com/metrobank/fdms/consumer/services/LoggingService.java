/*
 *  Copyright (c) 2019 Metropolitan Bank & Trust Company
 *
 *  @author 33460
 *  @date 2019-08-16
 *  @email mark.to@metrobank.com.ph
 */
package ph.com.metrobank.fdms.consumer.services;

import java.util.HashMap;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class LoggingService {

	private static final Logger LOGGER = LoggerFactory.getLogger(LoggingService.class);

	public String log(String component, String uuid, String topic, String message, String info) {
		Map<String, String> map = new HashMap<>();
		if (!"".equals(component)) {
			map.put("COMPONENT", component);
		}
		if (!"".equals(uuid)) {
			map.put("UUID", uuid);
		}
		if (!"".equals(topic)) {
			map.put("TOPIC", topic);
		}
		if (!"".equals(message)) {
			map.put("MESSAGE", message);
		}
		if (!"".equals(info)) {
			map.put("INFO", info);
		}
		String stringMap = map.toString();
		LOGGER.info(stringMap);
		return stringMap;
	}
	
	public String error(String component, String errorCode, String errorMessage, Throwable t)
	{
		Map<String, String> map = new HashMap<>();
		if (!"".equals(component))
		{
			map.put("COMPONENT", component);
		}
		if (!"".equals(errorCode))
		{
			map.put("ERROR", errorCode);
		}
		if (!"".equals(errorMessage))
		{
			map.put("ERROR MESSAGE", errorMessage);
		}
		String stringMap = map.toString();
		LOGGER.error(stringMap, t);
		return stringMap;
	}

	
}
