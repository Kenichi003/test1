/*
 *  Copyright (c) 2019 Metropolitan Bank & Trust Company
 *
 *  @author 33460
 *  @date 2019-08-16
 *  @email mark.to@metrobank.com.ph
 */
package ph.com.metrobank.fdms.consumer.model;

import org.springframework.beans.factory.annotation.Autowired;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import ph.com.metrobank.fdms.consumer.services.LoggingService;

public class Format {

	@Autowired
	private LoggingService loggingService;
	
	@Override
	public String toString() {
		try {
			return new ObjectMapper().enable(SerializationFeature.ORDER_MAP_ENTRIES_BY_KEYS).writeValueAsString(this);
		} catch (JsonProcessingException e) {
			loggingService.error(this.getClass().toString(), "", e.getMessage(), e);
			return "";
		}
	}

}
