
package ph.com.metrobank.fdms.consumer.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

public class ConsumerResponse extends Format {
	@JsonInclude(Include.NON_NULL)
	private String transactionCode;
	@JsonInclude(Include.NON_NULL)
	private String transactionDesc;

	public ConsumerResponse() {
		super();
	}

	public String getTransactionCode() {
		return transactionCode;
	}

	public void setTransactionCode(String transactionCode) {
		this.transactionCode = transactionCode;
	}

	public String getTransactionDesc() {
		return transactionDesc;
	}

	public void setTransactionDesc(String transactionDesc) {
		this.transactionDesc = transactionDesc;
	}

}
