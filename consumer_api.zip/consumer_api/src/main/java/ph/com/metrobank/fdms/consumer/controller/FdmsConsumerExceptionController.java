package ph.com.metrobank.fdms.consumer.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import ph.com.metrobank.fdms.consumer.exception.FdmsConsumerApiException;
import ph.com.metrobank.fdms.consumer.exception.KafkaServerException;
import ph.com.metrobank.fdms.consumer.exception.ProcessorAuthenticationException;
import ph.com.metrobank.fdms.consumer.model.TraceLog;
import ph.com.metrobank.fdms.consumer.services.LoggingService;
import ph.com.metrobank.fdms.consumer.utils.ResponseBuilder;

@RestControllerAdvice
public class FdmsConsumerExceptionController {
	
	@Autowired
	private LoggingService loggingService;
	
	@Autowired
	private ResponseBuilder responseBuilder;

		@ExceptionHandler(ProcessorAuthenticationException.class)
		public ResponseEntity<Map<String, Object>> authenticateException(final ProcessorAuthenticationException exception, final HttpServletRequest request,
				final HttpServletResponse httpResponse) {

			loggingService.log(this.getClass().toString() + TraceLog.FDMS_CONSUMER_EXCEPTION_CONTROLLER, httpResponse.toString(), responseBuilder.authenticationFailed().toString(),exception.getMessage(), "");
			
			return new ResponseEntity<>(responseBuilder.authenticationFailed(), HttpStatus.FORBIDDEN);
		}
		
		@ExceptionHandler(KafkaServerException.class)
		public Map<String, Object> kafkaDown(final KafkaServerException exception, final HttpServletRequest request,
				final HttpServletResponse httpResponse)
		{

			loggingService.log(this.getClass().toString() + TraceLog.FDMS_CONSUMER_EXCEPTION_CONTROLLER, httpResponse.toString(), responseBuilder.kafkaDown().toString(), exception.getMessage(),"");
			
			return responseBuilder.kafkaDown();

		}
		
		@ExceptionHandler(FdmsConsumerApiException.class)
		public void fdmsException(final FdmsConsumerApiException exception, final HttpServletRequest request,
				final HttpServletResponse httpResponse)
		{
			loggingService.log(this.getClass().toString() + TraceLog.FDMS_CONSUMER_EXCEPTION_CONTROLLER, httpResponse.toString(), request.toString(), exception.getMessage(), "");
			
		}




}
