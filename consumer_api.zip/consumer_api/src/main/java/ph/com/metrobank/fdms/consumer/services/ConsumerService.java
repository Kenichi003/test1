package ph.com.metrobank.fdms.consumer.services;


import java.security.NoSuchAlgorithmException;
import java.util.Map;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import ph.com.metrobank.fdms.consumer.config.WebClientConfig;
import ph.com.metrobank.fdms.consumer.model.ConsumerResponse;
import ph.com.metrobank.fdms.consumer.model.FdmsPayload;
import ph.com.metrobank.fdms.consumer.model.ConsumerPayload;
import ph.com.metrobank.fdms.consumer.model.ConsumerRequestModel;
import ph.com.metrobank.fdms.consumer.model.ProcessorResponse;
import ph.com.metrobank.fdms.consumer.model.TraceLog;
import ph.com.metrobank.fdms.consumer.model.TransactionStatus;
import ph.com.metrobank.fdms.consumer.utils.ResponseBuilder;
import reactor.core.publisher.Mono;


@Service
public class ConsumerService {

	@Autowired
	private LoggingService loggingService;
	
	private WebClient webClient;
	
	@Value("${user.access.id}")
	private String accessId;
	
	@Value("${user.access.passphrase}")
	private String passPhrase;
	
	@Value("${user.access.shared.key}")
	private String secretKey;
	
	@Autowired
	private ResponseBuilder responseBuilder;
	
	@Autowired
	private AuthenticationService authenticationService;
	
	@Autowired
	public ConsumerService(WebClientConfig webClient) {
		
		this.webClient = webClient.getWebClient();
    }

	public ConsumerService(WebClient webClient) {

		this.webClient = webClient;
	}
	
	public ConsumerService(String baseUrl) {
		
		this.webClient = WebClient.builder().baseUrl(baseUrl)
				.defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .build();
	}

	public ProcessorResponse processMessage(ConsumerPayload kafkaMessage, String processorApiEndpoint) {
	
		return executeWebClientCall(kafkaMessage, processorApiEndpoint).block();
	}
	
	public Mono<ProcessorResponse> executeWebClientCall(ConsumerPayload kafkaMessage, String processorApiEndpoint) {
		
		Mono<ProcessorResponse> monoResponse = this.webClient.post()
				.uri(processorApiEndpoint)
				.body(Mono.just(kafkaMessage), JSONObject.class)
				.retrieve()
				.bodyToMono(ProcessorResponse.class);
		
		ConsumerRequestModel consumerRequest = kafkaMessage.getConsumerRequest();

		
		monoResponse.subscribe(response -> {
			if(response.getTransactionCode().equals(TransactionStatus.ACCEPTED.getCode())) {

        		loggingService.log(this.getClass().toString() + TraceLog.FDMS_KAFKA_SERVICE_PROCESSOR_RESPONSE, kafkaMessage.getConsumerRequest().getUuid(), kafkaMessage.getConsumerRequest().getTopic(),
        				response.toString(),"");

        } else if(response.getTransactionCode().equals(TransactionStatus.INVALID_REQUEST.getCode())) {

        	loggingService.log(this.getClass().toString() + TraceLog.FDMS_KAFKA_SERVICE_PROCESSOR_RESPONSE, consumerRequest.getUuid(), response.getTransactionCode() , response.getTransactionStatus(), "");

        } else if(response.getTransactionCode().equals(TransactionStatus.INTERNAL_SERVER_ERROR_ON_KAFKA.getCode())) {

        	loggingService.log(this.getClass().toString() + TraceLog.FDMS_KAFKA_SERVICE_PROCESSOR_RESPONSE, consumerRequest.getUuid(), response.getTransactionCode() , response.getTransactionStatus(), "");

        } else if(response.getTransactionCode().equals(TransactionStatus.AUTHENTICATION_ERROR.getCode())) {

        	loggingService.log(this.getClass().toString() + TraceLog.FDMS_KAFKA_SERVICE_PROCESSOR_RESPONSE, consumerRequest.getUuid(), response.getTransactionCode() , response.getTransactionStatus(), "");

        }

        });
		
		return monoResponse;
		
		
	}
	
	public Map<String, Object> kafkaToggle(FdmsPayload fdmsPayload, String figAuto, String property) {
		
		try {
			PropertiesConfiguration properties = new PropertiesConfiguration("application.properties");
			properties.setProperty(property, figAuto);
			properties.save();
			
			authenticationService.authenticate(fdmsPayload);
			
			loggingService.log(this.getClass().toString() + TraceLog.FDMS_KAFKA_CONTROLLER, "Property change:", property + " = " + figAuto, "", "");
			return responseBuilder.responseAccepted();
		} catch(ConfigurationException e) {
			loggingService.error(this.getClass().toString() + TraceLog.FDMS_KAFKA_CONTROLLER, e.toString(), e.getMessage(), e);
			return responseBuilder.fdmsErrorResponse(e.toString(), e.getMessage());
		}
		
	}

	public ConsumerResponse createInvalidRequestResponse(ConsumerResponse response) {
		response.setTransactionCode(TransactionStatus.INVALID_REQUEST.getCode());
		response.setTransactionDesc(TransactionStatus.INVALID_REQUEST.getDescription());
		return response;
	}
	
	public ConsumerResponse createInternalServerErrorResponse(ConsumerResponse response) {
		response.setTransactionCode(TransactionStatus.INTERNAL_SERVER_ERROR_ON_KAFKA.getCode());
		response.setTransactionDesc(TransactionStatus.INTERNAL_SERVER_ERROR_ON_KAFKA.getDescription());
		return response;
	}
	
	public ConsumerResponse createAuthenticationErrorResponse(ConsumerResponse response) {
		response.setTransactionCode(TransactionStatus.AUTHENTICATION_ERROR.getCode());
		response.setTransactionDesc(TransactionStatus.AUTHENTICATION_ERROR.getDescription());
		return response;
	}
	
	public ConsumerResponse createAcceptedResponse(ConsumerResponse response) {
		response.setTransactionCode(TransactionStatus.ACCEPTED.getCode());
		response.setTransactionDesc(TransactionStatus.ACCEPTED.getDescription());
		return response;
	}

}
