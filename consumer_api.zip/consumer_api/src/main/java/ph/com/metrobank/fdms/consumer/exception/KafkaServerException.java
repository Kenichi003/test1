package ph.com.metrobank.fdms.consumer.exception;

public class KafkaServerException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public KafkaServerException() {
		super();
	}
	
	public KafkaServerException(Throwable t) {	
		super();
	}

}
