package ph.com.metrobank.fdms.consumer.utils;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

@Component
public class ResponseBuilder {
	
	public Map<String, Object> success()
	{
		Map<String, Object> response = new LinkedHashMap<>();
		response.put(FdmsConstants.RESPONSE_TRANSCODE, FdmsConstants.SUCCESS_CODE);
		response.put(FdmsConstants.RESPONSE_TRANSDESC, FdmsConstants.SUCCESS_MSG);
		response.put(FdmsConstants.RESPONSE_TRANSDATE, DateUtils.transactionDate(FdmsConstants.FDMS_DATEFORMAT));


		return response;
	}
	
	public Map<String, Object> responseAccepted()
	{
		Map<String, Object> response = new LinkedHashMap<>();
		response.put(FdmsConstants.RESPONSE_TRANSCODE, FdmsConstants.PROCESSOR_ACCEPTED_CODE);
		response.put(FdmsConstants.RESPONSE_STATUS_DESC, FdmsConstants.PROCESSOR_ACCEPTED_MSG);

		return response;
	}
	
	public Map<String, Object> validationFailed(String uuid)
	{
		Map<String, Object> response = new LinkedHashMap<>();
		
		response.put(FdmsConstants.RESPONSE_UIID, uuid);
		response.put(FdmsConstants.RESPONSE_TRANSCODE, FdmsConstants.CONSUMER_API_ERROR_CODE);
		response.put(FdmsConstants.RESPONSE_STATUS_DESC, FdmsConstants.CONSUMER_API_ERROR);

		return response;
	}

	
	public Map<String, Object> authenticationFailed()
	{
		Map<String, Object> response = new LinkedHashMap<>();
		
		response.put(FdmsConstants.RESPONSE_TRANSCODE, FdmsConstants.PROCESSOR_AUTH_ERR_CODE);
		response.put(FdmsConstants.RESPONSE_STATUS_DESC, FdmsConstants.PROCESSOR_AUTH_ERR_MSG);

		return response;
	}


	public Map<String, Object> kafkaDown()
	{
		Map<String, Object> response = new LinkedHashMap<>();
		response.put(FdmsConstants.RESPONSE_TRANSCODE, FdmsConstants.KAFKA_SERVER_DOWN_CODE);
		response.put(FdmsConstants.RESPONSE_TRANSDESC, FdmsConstants.KAFKA_SERVER_DOWN_MSG);
		response.put(FdmsConstants.RESPONSE_TRANSDATE, DateUtils.transactionDate(FdmsConstants.FDMS_DATEFORMAT));

		return response;
	}
	
	public Map<String, Object> fdmsErrorResponse(String responseCode, String responseMsg)
	{
		Map<String, Object> response = new LinkedHashMap<>();
		response.put(responseCode, responseMsg);

		return response;
	}

}
