
package ph.com.metrobank.fdms.consumer.model;

import java.util.LinkedHashMap;
import java.util.Map;

public enum TransactionStatus {

	ACCEPTED("001", TransactionDesc.ACCEPTED),
	INVALID_REQUEST("002", TransactionDesc.INVALID_REQUEST), 
	INTERNAL_SERVER_ERROR_ON_KAFKA("003", TransactionDesc.INTERNAL_SERVER_ERROR_ON_KAFKA), 
	AUTHENTICATION_ERROR("004", TransactionDesc.AUTHENTICATION_ERROR);

	private final String code;
	private final String description;
	private static Map<String, String> mapStatus = new LinkedHashMap<>();

	static {
		for (TransactionStatus status : TransactionStatus.values()) {
			mapStatus.put(status.getCode(), status.getDescription());
		}
	}

	TransactionStatus(String code, String description) {
		this.code = code;
		this.description = description;
	}

	public String getCode() {
		return code;
	}

	public String getDescription() {
		return description;
	}


}
