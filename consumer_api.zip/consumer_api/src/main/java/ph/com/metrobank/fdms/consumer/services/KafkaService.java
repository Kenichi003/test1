package ph.com.metrobank.fdms.consumer.services;

import java.security.NoSuchAlgorithmException;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Component;

import org.springframework.kafka.support.KafkaHeaders;

import ph.com.metrobank.fdms.consumer.model.ConsumerRequestModel;
import ph.com.metrobank.fdms.consumer.model.ConsumerPayload;
import ph.com.metrobank.fdms.consumer.model.PayloadCredentials;
import ph.com.metrobank.fdms.consumer.model.TraceLog;
import ph.com.metrobank.fdms.consumer.utils.DateUtils;
import ph.com.metrobank.fdms.consumer.utils.FdmsConstants;
import ph.com.metrobank.sha256.encryption.util.SHAUtil;

@Component
public class KafkaService {

	@Autowired
	private GenerateUUIDService generateUUIDService;

	@Autowired
	private LoggingService loggingService;

	@Autowired
	private ConsumerService consumerService;
	
	@Value("${processor.api.mbo.mbos.endpoint.uri}")
	private String mboMbosEndpointUri; // For MBO and MBOS transaction

	@Value("${processor.api.atm.endpoint.uri}")
	private String atmEndpointUri; // For ATTRA ATM transaction
	
	@Value("${user.access.id}")
	private String accessId;
	
	@Value("${user.access.passphrase}")
	private String passPhrase;
	
	@Value("${user.access.shared.key}")
	private String secretKey;

	@KafkaListener(topics = "#{'${kafka.topic.list}'.split(',')}", groupId = "fdms-streams", autoStartup = "${consumer.listen.start}")
	public void commonListenerForMultipleTopics(Object message, @Header(KafkaHeaders.RECEIVED_TOPIC) String topic, ConsumerRecord<String, String> consumerRecord) {
		
		processKafkaMessage(consumerRecord, topic, mboMbosEndpointUri);

	} 
	
	@KafkaListener(topics = "${kafka.atm.topic}", autoStartup = "${consumer.listen.start}")
	public void commonListenerForATMTopics(Object message, @Header(KafkaHeaders.RECEIVED_TOPIC) String topic, ConsumerRecord<String, String> consumerRecord) {
		
		processKafkaMessage(consumerRecord, topic, atmEndpointUri);

	}
	
	public void processKafkaMessage(ConsumerRecord<String, String> consumerRecord, String topic, String processorApiEndpoint) {
		
		ConsumerPayload kafkaMessage = new ConsumerPayload();
		PayloadCredentials payloadCredentials = new PayloadCredentials();
		ConsumerRequestModel consumerRequest = new ConsumerRequestModel();
		String uuid = generateUUIDService.generateUUID();
	    

		    
		    String consumedMessage = consumerRecord.value();
		    
		    
		    consumerRequest.setTopic(topic);
		    consumerRequest.setUuid(uuid);
		    payloadCredentials.setSystemId(accessId);

		    String transactionDate = DateUtils.transactionDate(FdmsConstants.FDMS_DATEFORMAT); 

		    try {
				payloadCredentials.setPassword(SHAUtil.sha256(uuid + passPhrase + transactionDate));
			} catch (NoSuchAlgorithmException e) {
				
				loggingService.error(this.getClass().toString() + TraceLog.FDMS_KAFKA_SERVICE_LISTENER, uuid, e.getMessage(), e);
			}
			
		    kafkaMessage.setMsgBody(consumedMessage);  
		    kafkaMessage.setConsumerRequest(consumerRequest);
		    kafkaMessage.setCredentials(payloadCredentials);
		    kafkaMessage.setTransDateTimestamp(transactionDate);
			
			loggingService.log(this.getClass().toString() + TraceLog.FDMS_KAFKA_SERVICE_LISTENER, uuid, topic, "", "");
			
			consumerService.processMessage(kafkaMessage, processorApiEndpoint);
			
		
	}
	

}
