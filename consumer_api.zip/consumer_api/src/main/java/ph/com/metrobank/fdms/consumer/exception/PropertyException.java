package ph.com.metrobank.fdms.consumer.exception;

public class PropertyException extends Exception {
	
	private static final long serialVersionUID = 1L;

	private PropertyException()
	{
		super();
	}


}
