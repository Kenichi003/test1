package ph.com.metrobank.fdms.consumer.services;

import java.security.NoSuchAlgorithmException;

import org.apache.kafka.common.errors.ApiException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import ph.com.metrobank.fdms.consumer.exception.ProcessorAuthenticationException;
import ph.com.metrobank.fdms.consumer.model.FdmsPayload;
import ph.com.metrobank.fdms.consumer.model.TraceLog;
import ph.com.metrobank.sha256.encryption.util.SHAUtil;


@Component
public class AuthenticationService {
	
	@Autowired
	private LoggingService loggingService;
	
	@Value("${user.access.passphrase}")
	private String passPhrase;
	
	@Value("${processor.access.id}")
	private String accessId;

	public boolean authenticate(FdmsPayload payload) {
		
		if (!payload.getCredentials().getSystemId().equalsIgnoreCase(accessId))
		{
			throw new ProcessorAuthenticationException();
		}
		
		if(!configApiKey(payload).equalsIgnoreCase(payload.getCredentials().getPassword())) {
			throw new ProcessorAuthenticationException();
		}
		
		return true;

	}
	
	private String configApiKey(FdmsPayload payload)
	{	
		try
		{
			return SHAUtil.sha256(payload.getTranReferenceNo()+passPhrase);
		} catch (NoSuchAlgorithmException e)
		{
			loggingService.error(this.getClass().toString() + TraceLog.FDMS_CONSUMER_SERVICE_AUTHENTICATOR, payload.getTranReferenceNo(), e.getMessage(), e);
//			throw new ApiException(e);
			return e.getMessage();
		}

	}


}
