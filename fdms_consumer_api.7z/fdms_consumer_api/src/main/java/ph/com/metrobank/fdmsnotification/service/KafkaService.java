package ph.com.metrobank.fdmsnotification.service;


import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpRequest;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;


import java.io.IOException;


@Component
public class KafkaService {
	
	@Value("${processor.api.url}")
	private String processorLink;
	
	Logger LOG = LoggerFactory.getLogger(KafkaService.class);
	
	@KafkaListener(
			topics = "#{'${kafka.topic.list}'.split(',')}",
			groupId = "fdms-streams")
	void commonListenerForMultipleTopics(String message) {
		
		
		
		try {
			postKafkaMessage("","",message);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		LOG.info("MultipleTopicListener - {}", message);
		
		
		
	}
	
	void postKafkaMessage(String username, String password, String message) throws IOException {
		
		try (CloseableHttpClient httpclient = HttpClients.createDefault()) {
			
//            HttpPost httpPost = new HttpPost("http://localhost:8100/test/postKafka");
			
            HttpPost httpPost = new HttpPost(processorLink);
            
            //convert JSONString to JSONObject
//            try {
//   		     JSONObject jsonObject = new JSONObject(message);
//	   		}catch (JSONException err){
//	   			LOG.error("Error", err.toString());
//	   		}
            
            String jsonString = JSONObject.quote(message);
            
            httpPost.setHeader("Accept", "application/json");
            httpPost.setHeader("Content-type", "application/json");
            StringEntity requestEntity = new StringEntity(
            		jsonString,
            	    ContentType.APPLICATION_JSON);
            httpPost.setEntity(requestEntity);
            

            System.out.println("Executing request " + httpPost.getRequestLine());

            
         // Create a custom response handler
            ResponseHandler<String> responseHandler = new ResponseHandler<String>() {

                @Override
                public String handleResponse(
                        final HttpResponse response) throws ClientProtocolException, IOException {
                    int status = response.getStatusLine().getStatusCode();
                    if (status >= 200 && status < 300) {
                        HttpEntity entity = response.getEntity();
                        return entity != null ? EntityUtils.toString(entity) : null;
                    } else {
                        throw new ClientProtocolException("Unexpected response status: " + status);
                    }
                }

            };
            
            
            String responseBody = httpclient.execute(httpPost, responseHandler);
            System.out.println("----------------------------------------");
            System.out.println(responseBody);
            
        } catch (Exception e) {
        	LOG.error("Error ", e.toString());
        }
		
	}
	
}
