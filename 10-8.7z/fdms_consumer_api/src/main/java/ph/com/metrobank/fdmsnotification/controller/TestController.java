package ph.com.metrobank.fdmsnotification.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("test")
public class TestController {
	
	@Autowired
	KafkaTemplate<String, String> kafkaTemplate;
	
	private static final String TOPIC = "NFT_RSIGNUP";
	
	@GetMapping("/publish/{message}")
	public String test(@PathVariable("message") final String message) {
		
		kafkaTemplate.send(TOPIC, message);
		
	    return "publish succesfully";
	}
	
	@RequestMapping(value = "/getString", method = RequestMethod.GET,
			 consumes = "application/json")
	public String test2(@RequestBody Object message) {
		
		kafkaTemplate.send(TOPIC, message.toString());
		
	    return "published succesfully";
	}
	
	@RequestMapping(value = "/postKafka", method = RequestMethod.POST,
			 consumes = "application/json")
	public ResponseEntity<String> processorAPI(@RequestBody Object message) {
		
	    return new ResponseEntity<>("postKafka OK", HttpStatus.OK);
		
		
	}
	
	
	
}
