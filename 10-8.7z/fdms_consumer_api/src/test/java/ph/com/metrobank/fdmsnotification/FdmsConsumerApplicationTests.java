package ph.com.metrobank.fdmsnotification;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FdmsConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
